﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03_Cau5
{
    internal class KhachSan
    {
        private int ngayTro;
        private string loaiPhongTro;
        private int giaPhongTro;
        private List<Nguoi> thongTinNguoiThue;

        public int NgayTro { get => ngayTro; set => ngayTro = value; }
        public string LoaiPhongTro { get => loaiPhongTro; set => loaiPhongTro = value; }
        public int GiaPhongTro { get => giaPhongTro; set => giaPhongTro = value; }
        internal List<Nguoi> ThongTinNguoiThue { get => thongTinNguoiThue; set => thongTinNguoiThue = value; }
        public KhachSan()
        {
            thongTinNguoiThue = new List<Nguoi>();
        }
        public int TinhTienThueTro()
        {
            return (ngayTro * giaPhongTro);
        }
        public void NhapThongTinNguoiThueTro()
        {
            try
            {
                // Thêm các kiểm tra đầu vào ở đây
                Console.Write("Nhập số ngày trọ của khách hàng : ");
                ngayTro = int.Parse(Console.ReadLine());
                Console.Write("Loại phòng trọ của khách hàng : ");
                loaiPhongTro = Console.ReadLine();
                Console.Write("Giá phòng đơn : ");
                giaPhongTro = int.Parse(Console.ReadLine());
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Lỗi: Nhập sai định dạng. Vui lòng nhập lại.");
                NhapThongTinNguoiThueTro();
            }
        }
        public void XuatThongTinNguoiThueTro()
        {
            Console.WriteLine($"Họ Và Tên :{ngayTro}");
            Console.WriteLine($"Năm Sinh :{loaiPhongTro}");
            Console.WriteLine($"Số Chứng Minh Nhân Dân :{giaPhongTro}");
            Console.WriteLine();
        }
    }
}
