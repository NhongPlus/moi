﻿
using LAP03_Cau5;
using System;
using System.Text;

namespace LAP03Cau5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Unicode;
            int luaChon;
            int soLuong;
            List<Nguoi> nguoi = new List<Nguoi>();
            do
            {
                Console.WriteLine("1.Thuê Trọ Nào !!!");
                Console.WriteLine("2.Thông tin về số người thuê trọ");
                Console.WriteLine("3.Tìm kiếm thông tin trọ theo tên");
                Console.WriteLine("4.Tính tiền cho khách hàng khi thanh toán trả phòng");
                Console.WriteLine("5.Out");
                Console.Write("Mời bạn nhập lựa chọn : ");
                luaChon = int.Parse(Console.ReadLine());
                switch (luaChon)
                {
                    case 1:
                        Console.Write("Nhập số lượng khách trọ: ");
                        soLuong = int.Parse(Console.ReadLine());
                        for (int i = 0; i < soLuong; i++)
                        {
                            Nguoi nguoithue = new Nguoi();
                            Console.WriteLine($"Nhập thông tin khách trọ thứ {i + 1} :");
                            nguoithue.NhapThongTinKhachTro();
                            nguoi.Add(nguoithue);
                        }
                        break;
                    case 2:
                        Console.WriteLine("Thông tin các cá nhân hiện đang trọ ở khách sạn :");
                        Console.WriteLine("| Họ và tên | Năm sinh | Số CMND |");
                        Console.WriteLine("|-----------|----------|---------|");
                        for (int i = 0; i < nguoi.Count; i++)
                        {
                            nguoi[i].XuatThongTinKhachTro();
                        }
                        break;
                    case 3:
                        string findTen;
                        Console.Write("Nhập họ và tên khách trọ cần tìm:");
                        findTen = Console.ReadLine();
                        for(int i = 0;i < nguoi.Count; i++)
                        {
                            if(findTen == nguoi[i].HoTen)
                            {
                                nguoi[i].XuatThongTinKhachTro();
                            }
                        }
                        break;
                    case 4:
                        Console.WriteLine("Tính tiền cho khách hàng khi thanh toán trả phòng :");
                        KhachSan khachSan = new KhachSan();
                        khachSan.NhapThongTinNguoiThueTro();
                        Console.WriteLine($"Tiền phải trả của khách : {khachSan.TinhTienThueTro()}");
                        break;
                    case 5:
                        Console.WriteLine("Chương trình kết thúc.");
                        break;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng nhập lại.");
                        break;
                }
            } while (luaChon != 4);
        }
    }
}
