﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03_Cau5
{
    internal class Nguoi
    {
        private String hoTen;
        private DateTime namSinh;
        private int soCMND;

        public string HoTen { get => hoTen; set => hoTen = value; }
        public DateTime NamSinh { get => namSinh; set => namSinh = value; }
        public int SoCMND { get => soCMND; set => soCMND = value; }

        public void NhapThongTinKhachTro()
        {
            try
            {
                // Thêm các kiểm tra đầu vào ở đây
                Console.Write("Nhập Tên: ");
                hoTen = Console.ReadLine();
                Console.Write("Nhập Ngày Tháng Năm Sinh (dd/MM/yyyy): ");
                NamSinh = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
                Console.Write("Nhập Số CMND: ");
                SoCMND = int.Parse(Console.ReadLine());
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Lỗi: Nhập sai định dạng. Vui lòng nhập lại.");
                NhapThongTinKhachTro();
            }
        }
        public void XuatThongTinKhachTro()
        {
            Console.WriteLine($"{hoTen} | {namSinh} | {soCMND}");
            Console.WriteLine();
        }
    }    
}
