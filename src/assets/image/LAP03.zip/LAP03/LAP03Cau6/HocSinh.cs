﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03Cau6
{
    internal class HocSinh
    {
        private string hoTen;
        private int tuoi;
        private DateTime namSinh;
        private string queQuan;
        private bool gioiTinh;

        public bool GioiTinh { get => gioiTinh; set => gioiTinh = value; }
        public string QueQuan { get => queQuan; set => queQuan = value; }
        public DateTime NamSinh { get => namSinh; set => namSinh = value; }
        public string HoTen { get => hoTen; set => hoTen = value; }
        public int Tuoi
        {
            get => tuoi;
            set
            {
                if (value > 0 && value < 100)
                {
                    tuoi = value;
                }
            }
        }
        public void Nhap()
        {
            try
            {
                Console.Write("Nhập Tên: ");
                hoTen = Console.ReadLine();
                Console.Write("Nhập Tuổi: ");
                tuoi = int.Parse(Console.ReadLine());
                Console.Write("Nhập Ngày Tháng Năm Sinh (dd/MM/yyyy): ");
                NamSinh = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
                Console.Write("Nhập quê quán: ");
                queQuan = (Console.ReadLine());
                Console.Write("Nhập giới tính (Nam/Nữ): ");
                string gioiTinhInput = Console.ReadLine().ToLower(); // Chuyển chuỗi nhập về chữ thường để đơn giản hóa việc so sánh
                if (gioiTinhInput == "nam")
                {
                    gioiTinh = true;
                }
                else if (gioiTinhInput == "nữ" || gioiTinhInput == "nu")
                {
                    gioiTinh = false;
                }
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Lỗi: Nhập sai định dạng. Vui lòng nhập lại.");
                Nhap();
            }
        }
        public void Xuat()
        {
            Console.WriteLine($"{hoTen} | {tuoi} | {namSinh} | {gioiTinh} | {queQuan}");
            Console.WriteLine();
        }
    }
}
