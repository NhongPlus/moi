﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAP03Cau6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Unicode;
            int luaChon;
            List<HoSoHocSinh> hs = new List<HoSoHocSinh>();
            do
            {
                Console.WriteLine("1. Nhập thông tin học sinh.");
                Console.WriteLine("2. Hiển thị học sinh nữ sinh năm 1985.");
                Console.WriteLine("3. Tìm kiếm học sinh theo quê quán.");
                Console.WriteLine("4. Thoát.");
                Console.Write("Mời bạn chọn: ");
                luaChon = int.Parse(Console.ReadLine());
                switch (luaChon)
                {
                    case 1:
                        Console.Write("Nhập số lượng học sinh: ");
                        int soLuong = int.Parse(Console.ReadLine());
                        for (int i = 0; i < soLuong; i++)
                        {
                            Console.WriteLine($"Nhập thông tin học sinh thứ {i + 1}:");
                            HoSoHocSinh hoSoHocSinh = new HoSoHocSinh();
                            hoSoHocSinh.Nhap();
                            hs.Add(hoSoHocSinh);
                        }
                        break;
                    case 2:
                        Console.WriteLine("Danh sách học sinh nữ sinh năm 1985:");
                        Console.WriteLine(" Họ và tên | Tuổi | Năm sinh | Giới tính | Quê quán ");
                        Console.WriteLine("|----------|------|----------|-----------|---------|");
                        foreach (var hocSinh in hs)
                        {
                            foreach (var hsItem in hocSinh.HocSinhList)
                            {
                                if (!hsItem.GioiTinh && hsItem.NamSinh.Year == 1985)
                                {
                                    hsItem.Xuat();
                                }
                            }
                        }
                        break;
                    case 3:
                        Console.Write("Nhập quê quán cần tìm: ");
                        string quan = Console.ReadLine();
                        Console.WriteLine($"Danh sách học sinh có quê quán là {quan}:");
                        Console.WriteLine(" Họ và tên | Tuổi | Năm sinh | Giới tính | Quê quán ");
                        Console.WriteLine("|----------|------|----------|-----------|---------|");
                        foreach (var hocSinh in hs)
                        {
                            foreach (var hsItem in hocSinh.HocSinhList)
                            {
                                if (hsItem.QueQuan.Equals(quan))
                                {
                                    hsItem.Xuat();
                                }
                            }
                        }
                        break;
                    case 4:
                        Console.WriteLine("Chương trình kết thúc.");
                        break;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
                        break;
                }
            } while (luaChon != 4);
        }
    }
}
