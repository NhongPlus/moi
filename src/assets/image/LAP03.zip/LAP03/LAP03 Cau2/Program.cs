﻿using LAP03_Cau2;
using System;
using System.Reflection.Metadata;
using System.Text;

namespace LAP03Cau2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            int luaChon;
            List<Doccument> danhSachSach = new List<Doccument>();
            Book sach = new Book();
            NewSpaper baochi = new NewSpaper();
            Magazine tapChi = new Magazine();
            do
            {
                Console.WriteLine("1.Nhập thông tin cho Sách");
                Console.WriteLine("2.Hiển thị thông tin Sách");
                Console.WriteLine("3.Tìm Kiếm");
                Console.WriteLine("4.Out");
                Console.Write("Mời bạn nhập lựa chọn : ");
                luaChon = int.Parse(Console.ReadLine());
                switch (luaChon)
                {
                    case 1:
                        Console.WriteLine("");
                        Console.WriteLine("1.Sách");
                        Console.WriteLine("2.Báo");
                        Console.WriteLine("3.Tạp Chí");
                        Console.Write("Mời bạn nhập số để lựa chọn : ");
                        int luachon1;
                        luachon1 = int.Parse(Console.ReadLine());

                        // Khởi tạo một đối tượng mới mỗi khi nhập thông tin
                        Doccument newDoc = null;

                        switch (luachon1)
                        {
                            case 1:
                                newDoc = new Book();
                                break;
                            case 2:
                                newDoc = new NewSpaper();
                                break;
                            case 3:
                                newDoc = new Magazine();
                                break;
                            default:
                                Console.WriteLine("Không hợp lệ ");
                                break;
                        }

                        if (newDoc != null)
                        {
                            newDoc.NhapThongTin();
                            danhSachSach.Add(newDoc);
                        }
                        break;
                    case 2:
                        Console.WriteLine("Thông tin của Sách: ");
                        for(int i = 0; i < danhSachSach.Count; i++)
                        {
                            danhSachSach[i].HienThiThongTin();
                        }
                        break;
                    case 3:
                        string find;
                        Console.WriteLine("Nhập tên muốn tìm :");
                        find = Console.ReadLine();

                        switch (find.ToLower())
                        {
                            case "sách":
                                var sachTheoLoai = danhSachSach.OfType<Book>();
                                HienThiThongTinTatCa(sachTheoLoai);
                                break;
                            case "báo":
                                var baoTheoLoai = danhSachSach.OfType<NewSpaper>();
                                HienThiThongTinTatCa(baoTheoLoai);
                                break;
                            case "tạp chí":
                                var tapChiTheoLoai = danhSachSach.OfType<Magazine>();
                                HienThiThongTinTatCa(tapChiTheoLoai);
                                break;
                            default:
                                Console.WriteLine($"Không tìm thấy tài liệu có loại '{find}'.");
                                break;
                        }
                        break;

                        static void HienThiThongTinTatCa(IEnumerable<Doccument> danhSach)
                        {
                            if (danhSach.Any())
                            {
                                Console.WriteLine($"Thông tin của Tài Liệu: ");
                                foreach (var doc in danhSach)
                                {
                                    doc.HienThiThongTin();
                                }
                            }
                            else
                            {
                                Console.WriteLine("Không có tài liệu nào được tìm thấy.");
                            }
                        }
                    case 4:
                        Console.WriteLine("Chương trình kết thúc.");
                        break;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng nhập lại.");
                        break;
                }
            } while (luaChon != 4);
        }
    }
}