﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03_Cau2
{
    class Doccument
    {
        private int codeDoccument;
        private string publishBook; // xuất bản sách
        private int quantity; // Số lượng 

        protected int Quantity { get => quantity; set => quantity = value; }
        protected string PublishBook { get => publishBook; set => publishBook = value; }
        protected int CodeDoccument { get => codeDoccument; set => codeDoccument = value; }

        public virtual void HienThiThongTin()
        {
            Console.WriteLine($"Mã Tài Liệu : {codeDoccument}");
            Console.WriteLine($"Nhà Xuất Bản : {publishBook}");
            Console.WriteLine($"Số Lượng Phát Hành : {quantity}");
        }
        public virtual void NhapThongTin()
        {
            Console.Write($"Nhập thông tin cho Mã Tài Liệu: ");
            codeDoccument = int.Parse(Console.ReadLine());

            Console.Write($"Nhập thông tin cho Nhà Xuất Bản: ");
            publishBook = Console.ReadLine();

            Console.Write($"Nhập thông tin cho Số Lượng Phát Hành: ");
            quantity = int.Parse(Console.ReadLine());
        }
    }
}
