﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace LAP03_Cau2
{
    internal class NewSpaper : Doccument
    {
        private int dayRelease; // ngày phát hành

        public int DayRelease { get => dayRelease; set => dayRelease = value; }

        public override void HienThiThongTin()
        {
            base.HienThiThongTin();
            Console.WriteLine("Báo");
            Console.WriteLine($"Ngày Phát Hành : {dayRelease}");
            Console.WriteLine();
        }
        public override void NhapThongTin()
        {
            base.NhapThongTin();
            Console.Write($"Nhập thông tin cho Số Trang : ");
            dayRelease = int.Parse(Console.ReadLine());
        }
    }
}
