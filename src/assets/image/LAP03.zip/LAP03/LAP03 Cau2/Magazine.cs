﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace LAP03_Cau2
{
    internal class Magazine : Doccument
    {
        private int soPhatHanh;
        private int thangPhatHanh;

        public override void HienThiThongTin()
        {
            base.HienThiThongTin();
            Console.WriteLine("Tạp chí");
            Console.WriteLine($"Số Phát Hành : {soPhatHanh}");
            Console.WriteLine($"Tháng Phát Hành : {soPhatHanh}");
            Console.WriteLine();
        }
        public override void NhapThongTin()
        {
            base.NhapThongTin();
            Console.Write($"Nhập thông tin cho Số Phát Hành : ");
            soPhatHanh = int.Parse(Console.ReadLine());
            Console.Write($"Nhập thông tin cho Tháng Phát Hành : ");
            thangPhatHanh = int.Parse(Console.ReadLine());
        }
    }
}
