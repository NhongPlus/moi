﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03_Cau2
{
    internal class Book : Doccument
    {
        private string name;
        private int numberPage;

        protected int NumberPage { get => numberPage; set => numberPage = value; }
        protected string Name { get => name; set => name = value; }

        public override void HienThiThongTin()
        {
            base.HienThiThongTin();
            Console.WriteLine("Sách");
            Console.WriteLine($"Tên Tác Giả : {name}");
            Console.WriteLine($"Số Trang : {numberPage}");
            Console.WriteLine();
        }
        public override void NhapThongTin()
        {
            base.NhapThongTin();
            Console.Write($"Nhập thông tin cho Tên Tác Giả : ");
            name = Console.ReadLine();
            Console.Write($"Nhập thông tin cho Số Trang : ");
            numberPage = int.Parse(Console.ReadLine());
            Console.WriteLine();
        }
    }
}
