﻿using LAP03_Cau3;
using System;
using System.Text;

namespace LAP03
{
    class Program
    {
        static void Main(string[] args){
            Console.OutputEncoding = Encoding.Unicode;
            int luaChon;
            int luachon1;
            List<ThiSinh> thiSinh = new List<ThiSinh>();
            do
            {
                Console.WriteLine("1.Nhập Thông Tin Thí Sinh");
                Console.WriteLine("2.Hiển Thị Thông Tin Thí Sinh Trúng Tuyển");
                Console.WriteLine("3.Tìm Kiếm Theo Số Báo Danh");
                Console.WriteLine("4.Out");
                Console.Write("Mời bạn nhập lựa chọn : ");
                luaChon = int.Parse(Console.ReadLine());
                switch (luaChon)
                {
                    case 1:
                        Console.WriteLine("");
                        Console.WriteLine("1.Khối A");
                        Console.WriteLine("2.Khối B");
                        Console.WriteLine("3.Khối C");
                        Console.Write("Mời bạn nhập số để lựa chọn : ");
                        luachon1 = int.Parse(Console.ReadLine());
                        switch (luachon1)
                        {
                            case 1:
                                KhoiA banA = new KhoiA();
                                banA.NhapThongTin();
                                thiSinh.Add(banA);
                                break;
                            case 2:
                                KhoiB banB = new KhoiB();
                                banB.NhapThongTin();
                                thiSinh.Add(banB);
                                break;
                            case 3:
                                KhoiC banC = new KhoiC();
                                banC.NhapThongTin();
                                thiSinh.Add(banC);
                                break;
                            default:
                                Console.WriteLine("Không hợp lệ");
                                break;
                        }
                        break;
                    case 2:
                        Console.WriteLine("Số Thí Sinh Tốt Nghiệp");
                        for(int i = 0; i < thiSinh.Count; i++)
                        {
                            thiSinh[i].HienThiTotNghiep();
                        }
                        break;
                    case 3:
                        int find;
                        Console.Write("Nhập số báo danh :");
                        find = int.Parse(Console.ReadLine());
                        for(int i = 0; i < thiSinh.Count; i++)
                        {
                            if(find == thiSinh[i].SoBaoDanh)
                            {
                                thiSinh[i].HienThi();
                            }
                        }
                        break;
                    case 4:
                        Console.WriteLine("Chương trình kết thúc.");
                        break;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng nhập lại.");
                        break;
                }
            } while (luaChon != 4);
        }
    }
}