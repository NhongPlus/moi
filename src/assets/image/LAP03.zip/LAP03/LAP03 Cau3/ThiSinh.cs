﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03_Cau3
{
    internal class ThiSinh
    {
        private int soBaoDanh;
        private string hoTen;
        private string diaChi;
        private float uuTien;
        private List<ThiSinh> danhSachThiSinh = new List<ThiSinh>();
        public int SoBaoDanh { get => soBaoDanh; set => soBaoDanh = value; }
        public string HoTen { get => hoTen; set => hoTen = value; }
        public string DiaChi { get => diaChi; set => diaChi = value; }
        public float UuTien { get => uuTien; set => uuTien = value; }
        
        public virtual void NhapThongTin()
        {
            Console.Write("Nhập số báo danh : ");
            soBaoDanh = int.Parse(Console.ReadLine());
            Console.Write("Nhập họ tên : ");
            hoTen = (Console.ReadLine());
            Console.Write("Nhập địa chỉ : ");
            diaChi = (Console.ReadLine());
            Console.Write("Nhập số điểm ưu tiên : ");
            uuTien = float.Parse(Console.ReadLine());
            Console.WriteLine();
            danhSachThiSinh.Add(this);
        }

        public virtual void HienThi()
        {
            Console.WriteLine();
            int soThuTu = 1;
            Console.WriteLine($"{soThuTu}. Họ tên: {hoTen}");
            Console.WriteLine($"Số Báo Danh: {soBaoDanh}");
            Console.WriteLine($"Điểm Ưu Tiên: {uuTien}");
            Console.WriteLine($"Địa chỉ: {diaChi}");
            soThuTu++;
        }
        public virtual void HienThiTotNghiep()
        {

        }
    }
}
