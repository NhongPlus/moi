﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03_Cau3
{
    internal class KhoiC : ThiSinh
    {
        private float van;
        private float su;
        private float dia;

        public float Van { 
            get => van;
            set {
                if (value > 0 && value <= 10)
                    van = value;
            }
        }
        public float Su { 
            get => su;
            set {
                if (value > 0 && value <= 10)
                    su = value;
            }
        }
        public float Dia { 
            get => dia;
            set
            {
                if (value > 0 && value <= 10)
                    dia = value;
            }
        }
        public override void NhapThongTin()
        {
            base.NhapThongTin();
            Console.Write("Nhập điểm Văn : ");
            van = float.Parse(Console.ReadLine());
            Console.Write("Nhập điểm Sử : ");
            su = float.Parse(Console.ReadLine());
            Console.Write("Nhập điểm Địa : ");
            dia = float.Parse(Console.ReadLine());
            Console.WriteLine();
        }
        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Điểm Văn: {van}");
            Console.WriteLine($"Điểm Sử: {su}");
            Console.WriteLine($"Điểm Địa: {dia}");
            Console.WriteLine();
        }
        public override void HienThiTotNghiep()
        {
            base.HienThiTotNghiep();
            if (dia + su + van >= 13.5)
            {
                HienThi();
            }
        }
    }
}
