﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03_Cau3
{
    internal class KhoiB : ThiSinh
    {
        private float toan;
        private float hoa;
        private float sinh;

        public float Toan { 
            get => toan;
            set
            {
                if (value > 0 && value <= 10)
                    toan = value;
            }
        }
        public float Hoa { 
            get => hoa; 
            set {
                if (value > 0 && value <= 10)
                    hoa = value;
            }
        }
        public float Sinh { 
            get => sinh;
            set {
                if (value > 0 && value <= 10)
                    sinh = value;
            }
        }
        public override void NhapThongTin()
        {
            base.NhapThongTin();
            Console.Write("Nhập điểm Toán : ");
            toan = float.Parse(Console.ReadLine());
            Console.Write("Nhập điểm Hóa : ");
            hoa = float.Parse(Console.ReadLine());
            Console.Write("Nhập điểm Sinh : ");
            sinh = float.Parse(Console.ReadLine());
            Console.WriteLine();
        }
        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Điểm Toán: {toan}");
            Console.WriteLine($"Điểm Hóa: {hoa}");
            Console.WriteLine($"Điểm Sinh: {sinh}");
            Console.WriteLine();
        }
        public override void HienThiTotNghiep()
        {
            base.HienThiTotNghiep();
            if (sinh + hoa + toan >= 16)
            {
                HienThi();
            }
        }
    }
}
