﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03_Cau3
{
    internal class KhoiA : ThiSinh
    {
        private float toan;
        private float hoa;
        private float ly;

        public float Toan { 
            get => toan;
            set
            {
                if (value > 0 && value <= 10)
                    toan = value;
            }
        }
        public float Hoa { 
            get => hoa;
            set
            {
                if (value > 0 && value <= 10)
                    hoa = value;
            }
        }
        public float Ly { 
            get => ly;
            set
            {
                if (value > 0 && value <= 10)
                    ly = value;
            }
        }
        public override void NhapThongTin()
        {
            base.NhapThongTin();
            Console.Write("Nhập điểm Toán : ");
            toan = float.Parse(Console.ReadLine());
            Console.Write("Nhập điểm Lý : ");
            ly = float.Parse(Console.ReadLine());
            Console.Write("Nhập điểm Hóa : ");
            hoa = float.Parse(Console.ReadLine());
            Console.WriteLine();
        }
        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Điểm Toán: {toan}");
            Console.WriteLine($"Điểm Lý: {ly}");
            Console.WriteLine($"Điểm Hóa: {hoa}");
            Console.WriteLine();
        }
        public override void HienThiTotNghiep()
        {
            base.HienThiTotNghiep();
            if( ly + hoa + toan >= 15)
            {
                HienThi();
            }
        }
    }
}
