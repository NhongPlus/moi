﻿using LAP03_Cau4;
using System;
using System.Text;

namespace LAP03Cau4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Unicode;
            int luaChon;
            int soLuong;
            List<Nguoi> nguoiArray = new List<Nguoi>();
            List<KhuPho> phoArray = new List<KhuPho>();

            do
            {
                Console.WriteLine("1.Nhập số lượng hộ dân");
                Console.WriteLine("2.Tìm kiếm thông tin về hộ dân theo họ tên hoặc theo số nhà");
                Console.WriteLine("3.Hiển thị thông tin cho toàn bộ các hộ dân trong khu phố");
                Console.WriteLine("4.Out");
                Console.Write("Mời bạn nhập lựa chọn : ");
                luaChon = int.Parse(Console.ReadLine());
                switch (luaChon)
                {
                    case 1:
                        Console.Write("Nhập số lượng hộ dân: ");
                        soLuong = int.Parse(Console.ReadLine());
                        for (int i = 0; i < soLuong; i++)
                        {
                            KhuPho khuPho = new KhuPho();
                            Console.WriteLine($"Nhập thông tin cho hộ dân thứ {i + 1}:");
                            khuPho.NhapThongTinHoDan();
                            phoArray.Add(khuPho);
                        }
                        break;
                    case 2:
                        Console.WriteLine("Tìm kiếm thông tin về hộ dân");
                        Console.Write("Nhập số nhà hoặc họ tên để tìm kiếm: ");
                        string input = Console.ReadLine();
                        bool found = false;
                        foreach (var khuPho in phoArray)
                        {
                            if (khuPho.SoNha.ToString() == input)
                            {
                                khuPho.ShowThongTin();
                                found = true;
                            }
                            else
                            {
                                foreach (var nguoi in khuPho.DanhSachNguoi)
                                {
                                    if (nguoi.HoTen == input)
                                    {
                                        khuPho.ShowThongTin();
                                        found = true;
                                        break;
                                    }
                                }
                            }
                        }
                        if (!found)
                        {
                            Console.WriteLine("Không tìm thấy thông tin cho số nhà hoặc họ tên đã nhập.");
                        }
                        break;

                    case 3:
                        Console.WriteLine("Hiển thị thông tin cho toàn bộ các hộ dân trong khu phố");
                        foreach (var khuPho in phoArray)
                        {
                            khuPho.ShowThongTin();
                        }
                        break;
                    case 4:
                        Console.WriteLine("Chương trình kết thúc.");
                        break;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng nhập lại.");
                        break;
                }
            } while (luaChon != 4);
        }
    }
}
