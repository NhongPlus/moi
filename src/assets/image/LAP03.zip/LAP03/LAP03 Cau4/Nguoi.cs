﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03_Cau4
{
    internal class Nguoi
    {
        private int soCMND;
        private string hoTen;
        private string ngheNghiep;
        private int tuoi;
        private DateTime namSinh;

        public int SoCMND { get => soCMND; set => soCMND = value; }
        public string HoTen { get => hoTen; set => hoTen = value; }
        public string NgheNghiep { get => ngheNghiep; set => ngheNghiep = value; }
        public int Tuoi
        {
            get => tuoi;
            set
            {
                if (value > 0 && value < 100)
                {
                    tuoi = value;
                }
            }
        }
        public DateTime NamSinh { get => namSinh; set => namSinh = value; }
        
        public void NhapThongTin()
        {
            try
            {
                // Thêm các kiểm tra đầu vào ở đây
                Console.Write("Nhập Tên: ");
                hoTen = Console.ReadLine();
                Console.Write("Nhập Ngày Tháng Năm Sinh (dd/MM/yyyy): ");
                namSinh = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
                Console.Write("Nhập Số CMND: ");
                soCMND = int.Parse(Console.ReadLine());
                Console.Write("Nhập Tên Nghề Nghiệp: ");
                ngheNghiep = Console.ReadLine();
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Lỗi: Nhập sai định dạng. Vui lòng nhập lại.");
                NhapThongTin();
            }
        }
        public void ShowThongTin()
        {
            Console.WriteLine($"Họ Và Tên :{hoTen}");
            Console.WriteLine($"Tuổi :{tuoi}");
            Console.WriteLine($"Năm Sinh :{namSinh}");
            Console.WriteLine($"Số Chứng Minh Nhân Dân :{soCMND}");
            Console.WriteLine($"Nghề Nghiệp :{ngheNghiep}");
            Console.WriteLine();
        }
    }
}
