﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03_Cau4
{
    internal class KhuPho
    {
        private int soThanhVien;
        private int soNha;
        private List<Nguoi> danhSachNguoi;
        public int SoNha { get => soNha; set => soNha = value; }
        public int SoThanhVien { get => soThanhVien; set => soThanhVien = value; }
        internal List<Nguoi> DanhSachNguoi { get => danhSachNguoi; set => danhSachNguoi = value; }
        public void TimTheoSoNha(int SoNhaDan)
        {
            if (SoNhaDan == soNha)
            {
                ShowThongTin();
            }
        }
        public KhuPho()
        {
            danhSachNguoi = new List<Nguoi>();
        }
        public void NhapThongTinHoDan()
        {
            Console.Write("Nhập Số Thành Viên : ");
            soThanhVien = int.Parse(Console.ReadLine());
            Console.Write("Nhập Số Nhà : ");
            soNha = int.Parse(Console.ReadLine());
            Console.WriteLine("Nhập Danh Sách Cá Nhân Trong Hộ Gia Đình ");
            for (int i = 0; i < soThanhVien; i++)
            {
                // Tạo đối tượng nguoi
                Nguoi nguoi = new Nguoi();
                // Nhập thông tin cho cá nhân thứ i
                nguoi.NhapThongTin();
                // Thêm cá nhân thứ i vào danh sách
                danhSachNguoi.Add(nguoi);
            }
        }
        public void ShowThongTin()
        {
            Console.WriteLine($"Số Thành Viên : {soThanhVien}");
            Console.WriteLine($"Số Nhà : {soNha}");
            Console.WriteLine($"Danh Sách Cá Nhân Trong Gia Đình : {danhSachNguoi}");
            Console.WriteLine();
        }
    }
}