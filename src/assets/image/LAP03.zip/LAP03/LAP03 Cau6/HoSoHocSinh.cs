﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03_Cau6
{
    internal class HoSoHocSinh
    {
        private string lop;
        private int khoaHoc;
        private int kyHoc;
        private List<HocSinh> hocSinhList;

        public int KyHoc { get => kyHoc; set => kyHoc = value; }
        public int KhoaHoc { get => khoaHoc; set => khoaHoc = value; }
        public string Lop { get => lop; set => lop = value; }
        internal List<HocSinh> HocSinhList { get => hocSinhList; set => hocSinhList = value; }
        
        public HoSoHocSinh() { 
            hocSinhList = new List<HocSinh>();
        }
        public void Nhap()
        {
            try
            {
                HocSinh hs = new HocSinh();
                hs.Nhap();
                hocSinhList.Add(hs);
                Console.Write("Nhập Lớp : ");
                lop = Console.ReadLine();
                Console.Write("Nhập Khóa Học: ");
                khoaHoc = int.Parse(Console.ReadLine());
                Console.Write("Nhập Học Kỳ: ");
                kyHoc = int.Parse(Console.ReadLine());
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Lỗi: Nhập sai định dạng. Vui lòng nhập lại.");
                Nhap();
            }
        }
        public void Xuat()
        {
            //Console.WriteLine($"{hoTen} | {tuoi} | {namSinh} | {gioiTinh} | {queQuan}");
            Console.WriteLine();
        }
    }
}
