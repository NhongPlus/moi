﻿using LAP03_Cau6;
using System;
using System.Text;

namespace LAP03Cau6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            static void Main(string[] args)
            {
                Console.OutputEncoding = Encoding.Unicode;
                int luaChon;
                int soLuong;
                List<HocSinh> nguoi = new List<HocSinh>();
                List<HoSoHocSinh> hs = new List<HoSoHocSinh>();
                do
                {
                    Console.WriteLine("1.Nhập thông tin học sinh !!!");
                    Console.WriteLine("2.Hiển thị ra màn hình tất cả những học sinh nữ và sinh năm 1985.");
                    Console.WriteLine("3.Tìm kiếm học sinh theo quê quán.");
                    Console.WriteLine("4.Out");
                    Console.Write("Mời bạn nhập lựa chọn : ");
                    luaChon = int.Parse(Console.ReadLine());
                    switch (luaChon)
                    {
                        case 1:
                            Console.Write("Nhập số lượng học sinh: ");
                            soLuong = int.Parse(Console.ReadLine());
                            for (int i = 0; i < soLuong; i++)
                            {
                                HoSoHocSinh hoSoHocSinh = new HoSoHocSinh();
                                HocSinh hsinh = new HocSinh();
                                Console.WriteLine($"Nhập thông tin học sinh thứ {i + 1} :");
                                hoSoHocSinh.Nhap();
                                hs.Add(hoSoHocSinh);
                            }
                            break;
                        case 2:
                            Console.WriteLine("Danh sách học sinh nữ sinh năm 1985 :");
                            Console.WriteLine(" Họ và tên | Tuổi | Năm sinh | Giới tính | Quê quán ");
                            Console.WriteLine("|----------|------|----------|-----------|---------|");
                            for (int i = 0; i < nguoi.Count; i++)
                            {
                                if (nguoi[i].GioiTinh == false && nguoi[i].NamSinh.Year < 1985)
                                {
                                    nguoi[i].Xuat();
                                }
                            }
                            break;
                        case 3:
                            string findDiaChi;
                            Console.Write("Danh sách học sinh có quê quán là :");
                            findDiaChi = Console.ReadLine();
                            for (int i = 0; i < nguoi.Count; i++)
                            {
                                if (findDiaChi == nguoi[i].QueQuan)
                                {
                                    nguoi[i].Xuat();
                                }
                            }
                            break;
                        case 4:
                            Console.WriteLine("Chương trình kết thúc.");
                            break;
                        default:
                            Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng nhập lại.");
                            break;
                    }
                } while (luaChon != 4);
            }
        }
    }
}