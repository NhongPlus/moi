﻿using System;
using System.Text;

namespace LAP03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            int luaChon;
            List<CanBo> danhSachCanBo = new List<CanBo>();
            do
            {
                Console.WriteLine("1.Nhập thông tin cho cán bộ");
                Console.WriteLine("2.Hiển thị thông tin cán bộ");
                Console.WriteLine("3.Tìm Kiếm");
                Console.WriteLine("4.Out");
                Console.Write("Mời bạn nhập lựa chọn : ");
                luaChon = int.Parse(Console.ReadLine());
                switch (luaChon)
                {
                    case 1:
                        Console.WriteLine("");
                        Console.WriteLine("1.Công Nhân");
                        Console.WriteLine("2.Kỹ Sư");
                        Console.WriteLine("3.Nhân Viên");
                        Console.Write("Mời bạn nhập số để lựa chọn : ");
                        int luachon1;
                        luachon1 = int.Parse(Console.ReadLine());
                        if (luachon1 == 1)
                        {
                            CongNhan Congnhan = new CongNhan();  
                            Congnhan.NhapThongTinCanBo();
                            danhSachCanBo.Add(Congnhan);
                        }
                        else if (luachon1 == 2)
                        {
                            KySu kySu = new KySu();
                            kySu.NhapThongTinCanBo();
                            danhSachCanBo.Add(kySu);
                        }
                        else if (luachon1 == 3)
                        {
                            NhanVien nhanVien = new NhanVien();  
                            nhanVien.NhapThongTinCanBo();
                            danhSachCanBo.Add(nhanVien);
                        }
                        else
                        {
                            Console.WriteLine("Không hợp lệ ");
                        }
                        break;
                    case 2:
                        Console.WriteLine("Thông tin của Cán Bộ: \n");
                        foreach(CanBo canBo in danhSachCanBo) { // (int i in danhSach) kiểu như vậy 
                            canBo.HienThiThongTin();
                            Console.WriteLine();
                            // cán bộ có thể trỏ vào canbo hoặc kysu , congnhan ...  ( Tính Chất 4 Tính đa hình )
                        }
                        break;
                    case 3:
                        string findName;
                        Console.Write("Nhập tên muốn tìm :");
                        findName = Console.ReadLine();
                        for(int i = 0; i < danhSachCanBo.Count; i++)
                        {
                            if (findName == danhSachCanBo[i].HoTen)
                            {
                                danhSachCanBo[i].HienThiThongTin();
                            }
                            else
                            {
                                Console.WriteLine("Không tìm thấy cán bộ ");
                            }
                        }
                        break;
                    case 4:
                        Console.WriteLine("Chương trình kết thúc.");
                        break;

                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng nhập lại.");
                        break;
                }
            } while (luaChon != 4);
        }
    }
}
