﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03
{
    internal class KySu : CanBo
    {
        private string nganhDaoTao;
        public string NganhDaoTao { 
            get => nganhDaoTao; 
            set => nganhDaoTao = value; 
        }
        public override void HienThiThongTin()
        {
            base.HienThiThongTin();
            Console.WriteLine($"Cấp Bậc: {nganhDaoTao}");
        }
        public override void NhapThongTinCanBo()
        {
            base.NhapThongTinCanBo();
            Console.Write("Nhập bậc: ");
            nganhDaoTao = Console.ReadLine();
        }
    }
}
