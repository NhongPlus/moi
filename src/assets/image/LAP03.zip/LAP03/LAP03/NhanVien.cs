﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03
{
    internal class NhanVien : CanBo
    {
        private string congViec;
        public string CongViec { 
            get => congViec; 
            set => congViec = value; 
        }
        public override void HienThiThongTin()
        {
            base.HienThiThongTin();
            Console.WriteLine($"Cấp Bậc: {congViec}");
        }
        public override void NhapThongTinCanBo()
        {
            base.NhapThongTinCanBo();
            Console.Write("Nhập bậc: ");
            congViec = Console.ReadLine();
        }
    }
}
