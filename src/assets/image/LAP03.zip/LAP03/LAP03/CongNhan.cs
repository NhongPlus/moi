﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAP03
{
    class CongNhan : CanBo
    {
        private int bac;
        public int Bac
        {
            get => bac;
            set => bac = value;
        }
        public override void HienThiThongTin()
        {
            base.HienThiThongTin();
            Console.Write($"Cấp Bậc: {bac}");
        }
        public override void NhapThongTinCanBo()
        {
            base.NhapThongTinCanBo();
            Console.Write("Nhập bậc: ");
            bac = int.Parse(Console.ReadLine());
        }
    }
}
