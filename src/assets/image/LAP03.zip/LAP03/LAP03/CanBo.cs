﻿using System;

namespace LAP03
{
    class CanBo
    {
        private string hoTen;
        private DateTime namSinh;
        private string gioiTinh;
        private string diaChi;

        public string HoTen
        {
            get => hoTen;
            set => hoTen = value;
        }

        public DateTime NamSinh
        {
            get => namSinh;
            set => namSinh = value;
        }

        public string GioiTinh
        {
            get => gioiTinh;
            set => gioiTinh = value;
        }

        public string DiaChi
        {
            get => diaChi;
            set => diaChi = value;
        }

        public virtual void HienThiThongTin()
        {
            Console.WriteLine();
            int soThuTu = 1;
            Console.WriteLine($"{soThuTu}. Họ tên: {hoTen}");
            Console.WriteLine($"Ngày sinh: {namSinh.ToShortDateString()}");
            Console.WriteLine($"Giới tính: {gioiTinh}");
            Console.WriteLine($"Địa chỉ: {diaChi}");
            soThuTu++;
            Console.WriteLine();
        }
        public virtual void NhapThongTinCanBo()
        {
            Console.Write("Nhập họ tên: ");
            hoTen = Console.ReadLine();
            Console.Write("Nhập giới tính: ");
            gioiTinh = Console.ReadLine();
            Console.Write("Nhập địa chỉ: ");
            diaChi = Console.ReadLine();
            Console.Write("Nhập ngày sinh (dd/MM/yyyy): ");
            namSinh = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
            Console.WriteLine();
        }
    }
}
